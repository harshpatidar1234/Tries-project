CS201 Project
Team Members
Mudit Gupta(2022CSB1094)
Rakshit Kaushal(2022CSB1110)
Harsh Patidar(2022MCB1265)
Amitoj Singh(2022MCB1256)
The read_me file explains how to give the input to the code presented in our project.The code can be firstly compiled using g++ filename.cpp and run using ./a.out command on the terminal.
The code then asks you to implement which application of tries:Dictionary or the phone directory.Enter the number accordingly.You will then be given 5 options and 6 th one for exiting the code.
1):Inserting a String:-This option asks you to insert a string you wish to insert.If it is for dictionary enter any combination of words or if its for a phone directory ,enter a number.
Note: In case of dictionary only include lowercase english alphabets(no special characters or numbers) in your string and in case of phone directory only include numbers from 0-9.(no special characters or alphabets).
2):Search a String:-The option searches for a given string entered by the user and responds accordingly.
3):Auto Completion of String:-This options asks you to enter a prefix of the string first(can be one letter/number or more than one) and then displays all those strings with that same prefix.
4):Delete a String:-This options deletes a string entered by the user if present else "No such string exist" will be printed.
5):Print all Strings:-The option prints all the strings that are present at that moment(i.e after multiple insertion or deletion calls).
6):Exit:-Exits the code.